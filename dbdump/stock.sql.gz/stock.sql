-- MySQL dump 10.13  Distrib 5.5.50, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: diaware
-- ------------------------------------------------------
-- Server version	5.5.50-0ubuntu0.14.04.1

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `stock`
--

DROP TABLE IF EXISTS `stock`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `stock` (
  `centreId` varchar(255) NOT NULL,
  `itemId` bigint(20) NOT NULL,
  `availableQuantity` int(11) DEFAULT NULL,
  `lastModifiedBy` varchar(255) DEFAULT NULL,
  `createdAt` datetime NOT NULL,
  `updatedAt` datetime NOT NULL,
  PRIMARY KEY (`centreId`,`itemId`),
  KEY `itemId` (`itemId`),
  CONSTRAINT `stock_ibfk_1` FOREIGN KEY (`itemId`) REFERENCES `item` (`itemId`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `stock`
--

LOCK TABLES `stock` WRITE;
/*!40000 ALTER TABLE `stock` DISABLE KEYS */;
INSERT INTO `stock` VALUES ('Varanasi_1',1,600,'Varanasi_1','2016-08-12 10:28:12','2016-08-12 10:28:12'),('Varanasi_1',4,2,'Varanasi_1','2016-08-12 10:28:12','2016-08-12 10:28:12'),('Varanasi_1',5,200,'Varanasi_1','2016-08-12 10:28:12','2016-08-12 10:28:12'),('Varanasi_1',6,12,'Varanasi_1','2016-08-12 10:28:12','2016-08-12 10:28:12'),('Varanasi_1',7,50,'Varanasi_1','2016-08-12 10:28:12','2016-08-12 10:28:12'),('Varanasi_1',8,12,'Varanasi_1','2016-08-12 10:28:12','2016-08-12 10:28:12'),('Varanasi_1',9,20,'Varanasi_1','2016-08-12 10:28:12','2016-08-12 10:28:12'),('Varanasi_1',10,312,'Varanasi_1','2016-08-12 10:28:12','2016-08-12 10:28:12'),('Varanasi_1',12,312,'Varanasi_1','2016-08-12 10:28:12','2016-08-12 10:28:12'),('Varanasi_1',19,500,'Varanasi_1','2016-08-12 10:28:12','2016-08-12 10:28:12'),('Varanasi_1',20,500,'Varanasi_1','2016-08-12 10:28:12','2016-08-12 10:28:12'),('Varanasi_1',21,200,'Varanasi_1','2016-08-12 10:28:12','2016-08-12 10:28:12'),('Varanasi_1',22,500,'Varanasi_1','2016-08-12 10:28:12','2016-08-12 10:28:12'),('Varanasi_1',23,100,'Varanasi_1','2016-08-12 10:28:12','2016-08-12 10:28:12'),('Varanasi_1',24,100,'Varanasi_1','2016-08-12 10:28:13','2016-08-12 10:28:13'),('Varanasi_1',25,200,'Varanasi_1','2016-08-12 10:28:13','2016-08-12 10:28:13'),('Varanasi_1',26,10,'Varanasi_1','2016-08-12 10:28:13','2016-08-12 10:28:13'),('Varanasi_1',27,10,'Varanasi_1','2016-08-12 10:28:13','2016-08-12 10:28:13'),('Varanasi_1',29,7200,'Varanasi_1','2016-08-12 10:28:13','2016-08-12 10:28:13'),('Varanasi_1',30,200,'Varanasi_1','2016-08-12 10:28:13','2016-08-12 10:28:13'),('Varanasi_1',31,1200,'Varanasi_1','2016-08-12 10:28:13','2016-08-12 10:28:13'),('Varanasi_1',34,60,'Varanasi_1','2016-08-12 10:28:13','2016-08-12 10:28:13'),('Varanasi_1',36,300,'Varanasi_1','2016-08-12 10:28:13','2016-08-12 10:28:13'),('Varanasi_1',37,1200,'Varanasi_1','2016-08-12 10:28:13','2016-08-12 10:28:13'),('Varanasi_1',39,15,'Varanasi_1','2016-08-12 10:28:13','2016-08-12 10:28:13'),('Varanasi_1',41,60,'Varanasi_1','2016-08-12 10:28:13','2016-08-12 10:28:13'),('Varanasi_1',42,24,'Varanasi_1','2016-08-12 10:28:13','2016-08-12 10:28:13'),('Varanasi_1',43,168,'Varanasi_1','2016-08-12 10:28:13','2016-08-12 10:28:13'),('Varanasi_1',44,216,'Varanasi_1','2016-08-12 10:28:13','2016-08-12 10:28:13'),('Varanasi_1',46,12,'Varanasi_1','2016-08-12 10:28:13','2016-08-12 10:28:13'),('Varanasi_1',48,100,'Varanasi_1','2016-08-12 10:28:13','2016-08-12 10:28:13'),('Varanasi_1',49,50,'Varanasi_1','2016-08-12 10:28:13','2016-08-12 10:28:13'),('Varanasi_1',51,350,'Varanasi_1','2016-08-12 10:28:13','2016-08-12 10:28:13'),('Varanasi_1',52,10,'Varanasi_1','2016-08-12 10:28:13','2016-08-12 10:28:13'),('Varanasi_1',55,20,'Varanasi_1','2016-08-12 10:28:13','2016-08-12 10:28:13'),('Varanasi_1',56,20,'Varanasi_1','2016-08-12 10:28:13','2016-08-12 10:28:13'),('Varanasi_1',57,20,'Varanasi_1','2016-08-12 10:28:13','2016-08-12 10:28:13'),('Varanasi_1',58,200,'Varanasi_1','2016-08-12 10:28:13','2016-08-12 10:28:13'),('Varanasi_1',59,15,'Varanasi_1','2016-08-12 10:28:13','2016-08-12 10:28:13'),('Varanasi_1',61,300,'Varanasi_1','2016-08-12 10:28:13','2016-08-12 10:28:13'),('Varanasi_1',70,600,'Varanasi_1','2016-08-12 10:28:13','2016-08-12 10:28:13');
/*!40000 ALTER TABLE `stock` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2016-09-03 12:25:38
