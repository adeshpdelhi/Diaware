-- MySQL dump 10.13  Distrib 5.5.50, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: diaware
-- ------------------------------------------------------
-- Server version	5.5.50-0ubuntu0.14.04.1

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `item`
--

DROP TABLE IF EXISTS `item`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `item` (
  `itemId` bigint(20) NOT NULL AUTO_INCREMENT,
  `itemName` varchar(255) DEFAULT NULL,
  `usageType` varchar(255) DEFAULT NULL,
  `brandName` varchar(255) DEFAULT NULL,
  `quantityMeasurementType` varchar(255) DEFAULT NULL,
  `lastModifiedBy` varchar(255) DEFAULT NULL,
  `createdAt` datetime NOT NULL,
  `updatedAt` datetime NOT NULL,
  PRIMARY KEY (`itemId`)
) ENGINE=InnoDB AUTO_INCREMENT=76 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `item`
--

LOCK TABLES `item` WRITE;
/*!40000 ALTER TABLE `item` DISABLE KEYS */;
INSERT INTO `item` VALUES (1,'Blood Tubing','utype1',NULL,'type1','admin','2016-08-12 09:08:15','2016-08-12 09:08:15'),(2,'Blood Tubing 5008S','utype1',NULL,'type1','admin','2016-08-12 09:41:38','2016-08-12 09:41:38'),(3,'Bac','utype1',NULL,'type1','admin','2016-08-12 09:41:38','2016-08-12 09:41:38'),(4,'Baccilol Spray Jar - 5Ltr','utype1',NULL,'type1','admin','2016-08-12 09:41:38','2016-08-12 09:41:38'),(5,'Band Aid','utype1',NULL,'type1','admin','2016-08-12 09:41:38','2016-08-12 09:41:38'),(6,'Betadine Lotion - 500Ml','utype2',NULL,'type1','admin','2016-08-12 09:41:38','2016-08-12 09:41:38'),(7,'BT Set','utype1',NULL,'type1','admin','2016-08-12 09:41:38','2016-08-12 09:41:38'),(8,'HD Machine Disinfectant - Diaclean','utype1',NULL,'type1','admin','2016-08-12 09:41:38','2016-08-12 09:41:38'),(9,'Cotton Roll - .5 Kg','utype2',NULL,'type1','admin','2016-08-12 09:41:38','2016-08-12 09:41:38'),(10,'Dialyzer Single Use 1.1','utype1',NULL,'type1','admin','2016-08-12 09:41:38','2016-08-12 09:41:38'),(11,'Dialyzer Single Use 1.3','utype1',NULL,'type1','admin','2016-08-12 09:41:38','2016-08-12 09:41:38'),(12,'Dialyzer Reuse 1.3','utype1',NULL,'type1','admin','2016-08-12 09:41:38','2016-08-12 09:41:38'),(13,'Dialyzer Reuse 1.4','utype1',NULL,'type1','admin','2016-08-12 09:41:38','2016-08-12 09:41:38'),(14,'Dialyzer Reuse 1.5','utype1',NULL,'type1','admin','2016-08-12 09:41:38','2016-08-12 09:41:38'),(15,'Dialyzer Reuse 1.8','utype1',NULL,'type1','admin','2016-08-12 09:41:38','2016-08-12 09:41:38'),(16,'Dialyzer High Flux','utype1',NULL,'type1','admin','2016-08-12 09:41:38','2016-08-12 09:41:38'),(17,'Dialyzer Port Caps','utype3',NULL,'type1','admin','2016-08-12 09:41:38','2016-08-12 09:41:38'),(18,'Blood Port Caps','utype3',NULL,'type1','admin','2016-08-12 09:41:38','2016-08-12 09:41:38'),(19,'Disposable Appron','utype2',NULL,'type1','admin','2016-08-12 09:41:38','2016-08-12 09:41:38'),(20,'Disposable Cap','utype3',NULL,'type1','admin','2016-08-12 09:41:38','2016-08-12 09:41:38'),(21,'Disposable Syringe 20Ml with Needle','utype1',NULL,'type1','admin','2016-08-12 09:41:38','2016-08-12 09:41:38'),(22,'Disposable Syringe 10Ml Without Needle','utype1',NULL,'type1','admin','2016-08-12 09:41:38','2016-08-12 09:41:38'),(23,'Disp. Syringe 1Ml (30G)','utype1',NULL,'type1','admin','2016-08-12 09:41:38','2016-08-12 09:41:38'),(24,'Disp. Syringe 2Ml (24G)','utype1',NULL,'type1','admin','2016-08-12 09:41:38','2016-08-12 09:41:38'),(25,'Disp. Syringe 5Ml (24G)','utype1',NULL,'type1','admin','2016-08-12 09:41:38','2016-08-12 09:41:38'),(26,'Catheter Double Lumen Curved','utype1',NULL,'type1','admin','2016-08-12 09:41:38','2016-08-12 09:41:38'),(27,'Catheter Double Lumen Straight','utype1',NULL,'type1','admin','2016-08-12 09:41:38','2016-08-12 09:41:38'),(28,'Dialysis On/Off kit','utype1',NULL,'type1','admin','2016-08-12 09:41:38','2016-08-12 09:41:38'),(29,'Examination Gloves','utype2',NULL,'type1','admin','2016-08-12 09:41:38','2016-08-12 09:41:38'),(30,'Face Mask','utype2',NULL,'type1','admin','2016-08-12 09:41:38','2016-08-12 09:41:38'),(31,'AVF Needle 16G','utype1',NULL,'type1','admin','2016-08-12 09:41:38','2016-08-12 09:41:38'),(32,'AVF Needle 17G','utype1',NULL,'type1','admin','2016-08-12 09:41:38','2016-08-12 09:41:38'),(33,'RO Anti Scalant','utype3',NULL,'type3','admin','2016-08-12 09:41:38','2016-08-12 09:41:38'),(34,'Gauze Than','utype2',NULL,'type1','admin','2016-08-12 09:41:38','2016-08-12 09:41:38'),(35,'Gauze Pieces','utype1',NULL,'type1','admin','2016-08-12 09:41:38','2016-08-12 09:41:38'),(36,'Heparin 25000IU','utype1',NULL,'type1','admin','2016-08-12 09:41:38','2016-08-12 09:41:38'),(37,'IV Set','utype1',NULL,'type1','admin','2016-08-12 09:41:38','2016-08-12 09:41:38'),(38,'Leucoplast 3 Inch','utype2',NULL,'type1','admin','2016-08-12 09:41:38','2016-08-12 09:41:38'),(39,'Leucoplast 4Inch','utype2',NULL,'type1','admin','2016-08-12 09:41:38','2016-08-12 09:41:38'),(40,'Micropore 1Inch','utype2',NULL,'type1','admin','2016-08-12 09:41:38','2016-08-12 09:41:38'),(41,'Micropore 2Inch','utype2',NULL,'type1','admin','2016-08-12 09:41:38','2016-08-12 09:41:38'),(42,'Micropore 3Inch','utype2',NULL,'type1','admin','2016-08-12 09:41:38','2016-08-12 09:41:38'),(43,'Normal Saline - 1000Ml','utype1',NULL,'type1','admin','2016-08-12 09:41:38','2016-08-12 09:41:38'),(44,'Normal Saline 500Ml','utype1',NULL,'type1','admin','2016-08-12 09:41:38','2016-08-12 09:41:38'),(45,'Normal Saline 100 ML','utype1',NULL,'type1','admin','2016-08-12 09:41:38','2016-08-12 09:41:38'),(46,'Dialyzer Disinfactant','utype2',NULL,'type1','admin','2016-08-12 09:41:38','2016-08-12 09:41:38'),(47,'Salt Tablet Bag','utype3',NULL,'type3','admin','2016-08-12 09:41:38','2016-08-12 09:41:38'),(48,'Surgical Gloves 6.5','utype1',NULL,'type2','admin','2016-08-12 09:41:38','2016-08-12 09:41:38'),(49,'Surgical Gloves 7','utype1',NULL,'type2','admin','2016-08-12 09:41:38','2016-08-12 09:41:38'),(50,'Surgical Gloves 7.5','utype1',NULL,'type2','admin','2016-08-12 09:41:38','2016-08-12 09:41:38'),(51,'Transducer Protector','utype1',NULL,'type1','admin','2016-08-12 09:41:38','2016-08-12 09:41:38'),(52,'Surface Disinfectant','utype3',NULL,'type3','admin','2016-08-12 09:41:38','2016-08-12 09:41:38'),(53,'Blade - 11No.','utype1',NULL,'type1','admin','2016-08-12 09:41:38','2016-08-12 09:41:38'),(54,'Cannula 16G','utype1',NULL,'type1','admin','2016-08-12 09:41:38','2016-08-12 09:41:38'),(55,'Catheter Single Lumen Straight','utype1',NULL,'type1','admin','2016-08-12 09:41:38','2016-08-12 09:41:38'),(56,'Guide Wire','utype1',NULL,'type1','admin','2016-08-12 09:41:38','2016-08-12 09:41:38'),(57,'Introducer Needle','utype1',NULL,'type1','admin','2016-08-12 09:41:38','2016-08-12 09:41:38'),(58,'Gluck Strip','utype1',NULL,'type1','admin','2016-08-12 09:41:38','2016-08-12 09:41:38'),(59,'Luco Band','utype1',NULL,'type1','admin','2016-08-12 09:41:38','2016-08-12 09:41:38'),(60,'Dialyzate Filter','utype3',NULL,'type1','admin','2016-08-12 09:41:38','2016-08-12 09:41:38'),(61,'Dialysate Part A (Dry)','utype1',NULL,'type1','admin','2016-08-12 09:41:38','2016-08-12 09:41:38'),(62,'Dialysaty Part A (Liquid)','utype1',NULL,'type3','admin','2016-08-12 09:41:38','2016-08-12 09:41:38'),(63,'Dextrose 25%','utype1',NULL,'type1','admin','2016-08-12 09:41:38','2016-08-12 09:41:38'),(64,'Xylocain','utype1',NULL,'type3','admin','2016-08-12 09:41:38','2016-08-12 09:41:38'),(65,'Sodium Hypocloride','utype3',NULL,'type3','admin','2016-08-12 09:41:38','2016-08-12 09:41:38'),(66,'EPO 4000IU','utype1',NULL,'type1','admin','2016-08-12 09:41:38','2016-08-12 09:41:38'),(67,'EPO 6000 IU','utype1',NULL,'type1','admin','2016-08-12 09:41:38','2016-08-12 09:41:38'),(68,'EPO 10000 IU','utype1',NULL,'type1','admin','2016-08-12 09:41:38','2016-08-12 09:41:38'),(69,'EPO 2000 IU','utype1',NULL,'type1','admin','2016-08-12 09:41:38','2016-08-12 09:41:38'),(70,'Dialysate Part B','utype1',NULL,'type1','admin','2016-08-12 09:41:38','2016-08-12 09:41:38'),(71,'BiBag','utype1',NULL,'type1','admin','2016-08-12 09:41:38','2016-08-12 09:41:38'),(72,'Catheter Triple Lumen Curved','utype1',NULL,'type1','admin','2016-08-12 09:41:38','2016-08-12 09:41:38'),(73,'Neosporin Powder','utype2',NULL,'type1','admin','2016-08-12 09:41:38','2016-08-12 09:41:38'),(74,'Suture Silk','utype1',NULL,'type1','admin','2016-08-12 09:41:38','2016-08-12 09:41:38'),(75,'Height Meter Tape','utype3',NULL,'type1','admin','2016-08-12 09:42:39','2016-08-12 09:42:39');
/*!40000 ALTER TABLE `item` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2016-09-03  5:20:18
